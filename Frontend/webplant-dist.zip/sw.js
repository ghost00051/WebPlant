const CACHE_NAME = 'ctp-v4'


const urlsToCache = [
    '/',
    '/plants',
    '/care',
    '/manifest.json',
    '/404.html'
]

self.addEventListener('install', (event) => {
    console.log('🔧 SW: install')
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) =>
            Promise.all(
                urlsToCache.map(url =>
                    cache.add(url).catch(err =>
                        console.warn(`⚠️ Не удалось закешировать ${url}:`, err)
                    )
                )
            )
        )
    )
    self.skipWaiting()
})

self.addEventListener('activate', (event) => {
    console.log('🔧 SW: activate')
    event.waitUntil(
        caches.keys().then((cacheNames) =>
            Promise.all(
                cacheNames
                    .filter((name) => name !== CACHE_NAME)
                    .map((name) => caches.delete(name))
            )
        )
    )
    self.clients.claim()
})

self.addEventListener('fetch', (event) => {
    const req = event.request

    if (req.method !== 'GET') return

    const url = new URL(req.url)

    if (
        url.pathname.startsWith('/api/') ||
        url.pathname.startsWith('/uploads/') ||
        url.origin !== self.location.origin
    ) {
        return
    }

    event.respondWith(
        fetch(req).catch(async () => {
            const cached = await caches.match(req)
            if (cached) return cached

            if (req.mode === 'navigate') {
                const fallback =
                    (await caches.match(req, { ignoreSearch: true })) ||
                    (await caches.match('/404.html'))
                if (fallback) return fallback
                return new Response('Нет подключения к сети', {
                    status: 503,
                    headers: { 'Content-Type': 'text/plain; charset=utf-8' }
                })
            }
            return new Response('', { status: 504, statusText: 'Offline' })
        })
    )
})

self.addEventListener('push', (event) => {
    console.log('📬 SW: push received')

    let data = {
        title: 'CheckThePlants',
        body: 'Новое уведомление',
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-192.png',
        data: {}
    }

    if (event.data) {
        try {
            data = { ...data, ...event.data.json() }
        } catch {
            data.body = event.data.text()
        }
    }

    const tag = data.data?.tag
        ? `plant-${data.data.plantId ?? 'x'}-${data.data.tag}`
        : `plant-${data.data?.plantId ?? Date.now()}`

    event.waitUntil(
        self.registration.showNotification(data.title, {
            body: data.body,
            icon: data.icon,
            badge: data.badge,
            tag,
            renotify: true,
            vibrate: [200, 100, 200],
            data: data.data || {},
            requireInteraction: false,
            actions: [
                { action: 'open', title: 'Открыть' }
            ]
        })
    )
})

self.addEventListener('notificationclick', (event) => {
    console.log('👆 SW: notification click', event.action)
    event.notification.close()

    const targetUrl = new URL(
        event.notification.data?.url || '/home',
        self.location.origin
    )
    const urlToOpen = targetUrl.origin === self.location.origin
        ? targetUrl.href
        : new URL('/home', self.location.origin).href

    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
            for (const client of clientList) {
                if (client.url.startsWith(self.location.origin) && 'focus' in client) {
                    return client.navigate(urlToOpen).then(() => client.focus())
                }
            }
            if (self.clients.openWindow) {
                return self.clients.openWindow(urlToOpen)
            }
        })
    )
})

self.addEventListener('pushsubscriptionchange', (event) => {
    console.log('🔄 SW: pushsubscriptionchange')

    event.waitUntil((async () => {
        try {
            const res = await fetch('/api/push/vapid-public-key', {
                credentials: 'include'
            })
            if (!res.ok) {
                throw new Error(`VAPID key request failed: HTTP ${res.status}`)
            }
            const { publicKey } = await res.json()
            if (typeof publicKey !== 'string' || !publicKey) {
                throw new Error('Server did not return a VAPID public key')
            }

            const sub = await self.registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(publicKey)
            })

            const saved = await fetch('/api/push/subscribe', {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ subscription: sub.toJSON() })
            })
            if (!saved.ok) {
                throw new Error(`Saving push subscription failed: HTTP ${saved.status}`)
            }
            console.log('✅ SW: подписка пересоздана и сохранена')
        } catch (e) {
            console.error('❌ SW: pushsubscriptionchange error:', e)
        }
    })())
})

function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4)
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
    const raw = atob(base64)
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)))
}